<?php
    header('Location: ProjetoIntegrador.html');
?>