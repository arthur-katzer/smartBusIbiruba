
<?php #pega os dados pra tabela
$conn = mysqli_connect('localhost', 'id20099248_smartbus_admin', '@Pastelao7pila', 'id20099248_smartbus');
$sql = "SELECT titulo, autor, texto FROM `sugestao`
";

#comando pra deletar
/*if (!empty($_GET['action']) and ($_GET['action'] == 'delete')) {
    $id = (int) $_GET['id'];
    mysqli_query($conn, "DELETE FROM sugestao where id='{$id}'");
}*/

$result = mysqli_query($conn, $sql);

echo "<pre>";
print_r($result);
echo "</pre>";

$itemSUDO = '';
while ($row = mysqli_fetch_assoc($result)) {

echo "<pre>";
print_r($row);
echo "</pre>";

    $items = file_get_contents('SugestaoList.html');
#   $items = str_replace('{id}',     $row['id'],     $items);
    $items = str_replace('{titulo}', $row['titulo'], $items);
    $items = str_replace('{autor}',  $row['autor'],  $items);
    $items = str_replace('{texto}',  $row['texto'],  $items);

    $itemSUDO .= $items;
}

$list = file_get_contents('SugestaoList.html');
$list = str_replace('{itemSUDO}', $itemSUDO, $list);
print $list;
