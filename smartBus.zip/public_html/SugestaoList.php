<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Projeto Integrador</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <link rel="stylesheet" href="/ProjetoIntegrador.css" />
    <link href="/css/bootstrap.min.css" rel="stylesheet">

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand" href="#">Menu</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="ProjetoIntegrador.html">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Tempo Real (em breve)</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="TelaSobre.html">Sobre</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="TelaIntegrantes.html">Integrantes</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="TelaSugest%C3%B5es.html">Sugestões</a>
          </li>
        </ul>
      </div>
    </nav>
  </head>

  <body>
    <style type="text/css">
      body {background-color: #87cefa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;}</style>
    <table border="1">
        <thead>
            <t>
                <td>Título</td>
                <td>Autor</td>
                <td>Texto</td>
            </t>
        </thead>

        <tbody>
            <?php
            $conn = mysqli_connect('localhost', 'id20099248_smartbus_admin', '@Pastelao7pila', 'id20099248_smartbus');
            $sql = "SELECT titulo, autor, texto FROM sugestao";


            $result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_assoc($result)) {

                $titulo      = $row['titulo'];
                $autor       = $row['autor'];
                $texto       = $row['texto'];
                        
                print "<td> {$titulo} </td>";
                print "<td> {$autor}  </td>";
                print "<td> {$texto}  </td>";

                print '</tr>';
            }

            ?>
        </tbody>
    </table>

        <a href="TelaSugestões.html">Envie sua sugestão!</a>

</body>

</html>